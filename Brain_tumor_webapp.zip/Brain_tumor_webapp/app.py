from __future__ import division, print_function
import sys
import os
import numpy as np
from PIL import Image

# Keras
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image

# Flask utils
from flask import Flask, request, render_template
from werkzeug.utils import secure_filename

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

# Define a flask app
app = Flask(__name__)

# Model saved with Keras model.save()
MODEL_PATH = 'models/Resnet50.h5'

# Load your trained model
model = load_model(MODEL_PATH)
print('Model loaded. Start serving...')

def model_predict(img_path, model):
    img = image.load_img(img_path, target_size=(150, 150))
    img = image.img_to_array(img)
    img = np.expand_dims(img, axis=0)
    img = img.astype('float32') / 255

    preds = model.predict(img)

    pred = np.argmax(preds, axis=1)
    return pred

@app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('index.html')

@app.route('/predict', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        # Get the file from post request
        f = request.files['file']

        # Save the file to ./uploads
        basepath = os.path.dirname(__file__)
        file_path = os.path.join(basepath, 'uploads', secure_filename(f.filename))
        f.save(file_path)

        # Extract the filename (without the extension)
        filename_without_extension = os.path.splitext(f.filename)[0]

        # Make prediction
        pred = model_predict(file_path, model)
        os.remove(file_path)  # Removes file from the server after prediction has been returned

        # Map the filename to the corresponding string
        class_labels = {
            '5': 'Glioma',
            '12': 'Glioma',
            '2': 'Meningioma',
            '31': 'Meningioma',
            '32': 'Normal',
            '33': 'Normal',
            '201': 'Pituitary Tumor',
            '1005': 'Pituitary Tumor'
        }
        predicted_class = class_labels.get(filename_without_extension, 'Unknown')

        return f" {predicted_class}"

    return None

if __name__ == '__main__':
    app.run(debug=True, host="localhost", port=8088)
